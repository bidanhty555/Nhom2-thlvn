﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace QLKQHT
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string connect = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;
        string mahs, tenhs,khoi,lop ,sdtph, diachi;
        Boolean gt;
        DateTime ns;
        protected void Page_Load(object sender, EventArgs e)
        {
            DDL_Load();
            DS_Load();
        }
        //Khải
        private void DDL_Load() 
        {
            if (ddlKhoi.SelectedItem.ToString() == "6")
            {
                ddlLop.Items.FindByValue("6A").Enabled = true;
                ddlLop.Items.FindByValue("6B").Enabled = true;
                ddlLop.Items.FindByValue("6C").Enabled = true;
                ddlLop.Items.FindByValue("6D").Enabled = true;
                ddlLop.Items.FindByValue("7A").Enabled = false;
                ddlLop.Items.FindByValue("7B").Enabled = false;
                ddlLop.Items.FindByValue("7C").Enabled = false;
                ddlLop.Items.FindByValue("7D").Enabled = false;
                ddlLop.Items.FindByValue("8A").Enabled = false;
                ddlLop.Items.FindByValue("8B").Enabled = false;
                ddlLop.Items.FindByValue("8C").Enabled = false;
                ddlLop.Items.FindByValue("8D").Enabled = false;
                ddlLop.Items.FindByValue("9A").Enabled = false;
                ddlLop.Items.FindByValue("9B").Enabled = false;
                ddlLop.Items.FindByValue("9C").Enabled = false;
                ddlLop.Items.FindByValue("9D").Enabled = false;
            }
            else if (ddlKhoi.SelectedItem.ToString() == "7")
            {
                ddlLop.Items.FindByValue("7A").Enabled = true;
                ddlLop.Items.FindByValue("7B").Enabled = true;
                ddlLop.Items.FindByValue("7C").Enabled = true;
                ddlLop.Items.FindByValue("7D").Enabled = true;
                ddlLop.Items.FindByValue("6A").Enabled = false;
                ddlLop.Items.FindByValue("6B").Enabled = false;
                ddlLop.Items.FindByValue("6C").Enabled = false;
                ddlLop.Items.FindByValue("6D").Enabled = false;
                ddlLop.Items.FindByValue("8A").Enabled = false;
                ddlLop.Items.FindByValue("8B").Enabled = false;
                ddlLop.Items.FindByValue("8C").Enabled = false;
                ddlLop.Items.FindByValue("8D").Enabled = false;
                ddlLop.Items.FindByValue("9A").Enabled = false;
                ddlLop.Items.FindByValue("9B").Enabled = false;
                ddlLop.Items.FindByValue("9C").Enabled = false;
                ddlLop.Items.FindByValue("9D").Enabled = false;
                
            }
            else if (ddlKhoi.SelectedItem.ToString() == "8")
            {
                ddlLop.Items.FindByValue("8A").Enabled = true;
                ddlLop.Items.FindByValue("8B").Enabled = true;
                ddlLop.Items.FindByValue("8C").Enabled = true;
                ddlLop.Items.FindByValue("8D").Enabled = true;
                ddlLop.Items.FindByValue("6A").Enabled = false;
                ddlLop.Items.FindByValue("6B").Enabled = false;
                ddlLop.Items.FindByValue("6C").Enabled = false;
                ddlLop.Items.FindByValue("6D").Enabled = false;
                ddlLop.Items.FindByValue("7A").Enabled = false;
                ddlLop.Items.FindByValue("7B").Enabled = false;
                ddlLop.Items.FindByValue("7C").Enabled = false;
                ddlLop.Items.FindByValue("7D").Enabled = false;
                ddlLop.Items.FindByValue("9A").Enabled = false;
                ddlLop.Items.FindByValue("9B").Enabled = false;
                ddlLop.Items.FindByValue("9C").Enabled = false;
                ddlLop.Items.FindByValue("9D").Enabled = false;
                
            }
            else if (ddlKhoi.SelectedItem.ToString() == "9")
            {
                ddlLop.Items.FindByValue("9A").Enabled = true;
                ddlLop.Items.FindByValue("9B").Enabled = true;
                ddlLop.Items.FindByValue("9C").Enabled = true;
                ddlLop.Items.FindByValue("9D").Enabled = true;
                ddlLop.Items.FindByValue("6A").Enabled = false;
                ddlLop.Items.FindByValue("6B").Enabled = false;
                ddlLop.Items.FindByValue("6C").Enabled = false;
                ddlLop.Items.FindByValue("6D").Enabled = false;
                ddlLop.Items.FindByValue("7A").Enabled = false;
                ddlLop.Items.FindByValue("7B").Enabled = false;
                ddlLop.Items.FindByValue("7C").Enabled = false;
                ddlLop.Items.FindByValue("7D").Enabled = false;
                ddlLop.Items.FindByValue("8A").Enabled = false;
                ddlLop.Items.FindByValue("8B").Enabled = false;
                ddlLop.Items.FindByValue("8C").Enabled = false;
                ddlLop.Items.FindByValue("8D").Enabled = false;
                
            }
        }

        private void DS_Load()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "select * from HOCSINH";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                dgvDanhSachHocSinh.DataSource = dt;
                dgvDanhSachHocSinh.DataBind();
            }
        }
        protected void dgvDanhSachHocSinh_SelectedIndexChanged(object sender, EventArgs e)
        {
          string maHS = dgvDanhSachHocSinh.SelectedRow.Cells[1].Text;
            using (SqlConnection conn = new SqlConnection(connect))
            {
                
                string sql = "select * from HOCSINH where MAHS=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma",maHS );
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    mahs = (string)dr["MAHS"];
                    tenhs = (string)dr["TENHOCSINH"];
                    gt = (Boolean)dr["GIOITINH"];
                    ns = (DateTime)dr["NGAYSINH"];
                    khoi = (string)dr["KHOI"];
                    lop = (string)dr["LOP"];
                    sdtph = (string)dr["SDTPHUHUYNH"];
                    diachi = (string)dr["DIACHI"];
                    txtMaHocSinh.Text = mahs;
                    txtTen.Text = tenhs;
                    if (gt == true)
                    {
                        RadioButtonList1.SelectedIndex = 0;
                    }
                    else
                    {
                        RadioButtonList1.SelectedIndex = 1;
                    }
                    txtNgaySinh.Text = ns.ToString();
                    ddlKhoi.Text = khoi;
                    txtSDTPhuHuynh.Text = sdtph;
                    txtDiaChi.Text = diachi;
                    DDL_Load();
                    ddlLop.Text = lop;
  
                }
                txtMaHocSinh.Enabled = false;
            } Label2.Text = "";
            
        }
        private void loadtrang()
        {
            txtMaHocSinh.Text = "";
            txtTen.Text = "";
            RadioButtonList1.SelectedIndex = -1;
            txtNgaySinh.Text = "";
            txtSDTPhuHuynh.Text = "";
            txtDiaChi.Text = "";
        }
        protected void btnSua_Click(object sender, EventArgs e)
        {
            string mahs = txtMaHocSinh.Text;
            using (SqlConnection conn = new SqlConnection(connect))
            {
                if ((txtMaHocSinh.Text == "") && (txtTen.Text == "") && (txtNgaySinh.Text == "")
                   && (txtDiaChi.Text == "") && (txtSDTPhuHuynh.Text == ""))
                    Label2.Text = "Vui lòng nhập đầy đủ thông tin!";
                else
                {
                    string sql = "update HOCSINH set TENHOCSINH=@ten,GIOITINH=@gt,NGAYSINH=@ns,KHOI=@khoi,LOP=@lop,SDTPHUHUYNH=@sdtph,DIACHI=@diachi where MAHS=@ma";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaHocSinh.Text.ToString());
                    cmd.Parameters.AddWithValue("@ten", txtTen.Text.ToString());
                    cmd.Parameters.AddWithValue("@gt", RadioButtonList1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@ns", txtNgaySinh.Text.ToString());
                    cmd.Parameters.AddWithValue("@khoi", ddlKhoi.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@lop", ddlLop.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@sdtph", txtSDTPhuHuynh.Text.ToString());
                    cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.ToString());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    DS_Load();
                    loadtrang();
                    Label2.Text = "Sửa thông tin học sinh: " + mahs + " thành công!";
                    txtMaHocSinh.Enabled = true;
                }
            }
        }

        protected void btnXoa_Click(object sender, EventArgs e)
        {
            string mahs = txtMaHocSinh.Text;
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "delete DIEM where MAHS=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", mahs);
                conn.Open();
                cmd.ExecuteNonQuery();
                string sql1 = "delete HOCSINH where MAHS=@ma";
                SqlCommand cmd1 = new SqlCommand(sql1, conn);
                cmd1.Parameters.AddWithValue("@ma", mahs);
                cmd1.ExecuteNonQuery();
                DS_Load();
                loadtrang();
                txtMaHocSinh.Enabled = true;
                Label2.Text = "Đã xóa học sinh " + mahs + " ra khỏi hệ thống!";   
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtMaHocSinh.Text;
                if ((txtMaHocSinh.Text=="")&&(txtTen.Text=="")&&(txtNgaySinh.Text=="")
                    &&(txtDiaChi.Text=="")&&(txtSDTPhuHuynh.Text==""))
                    Label2.Text="Vui lòng nhập đầy đủ thông tin!";
                else if (KiemTra() != 1)
                {   
                    
                    string sql = "INSERT INTO HOCSINH (MAHS,TENHOCSINH,GIOITINH,NGAYSINH,KHOI,LOP,SDTPHUHUYNH,DIACHI) VALUES (@ma,@ten,@gt,@ns,@khoi,@lop,@sdtph,@diachi)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaHocSinh.Text.ToString());
                    cmd.Parameters.AddWithValue("@ten", txtTen.Text.ToString());
                    cmd.Parameters.AddWithValue("@gt", RadioButtonList1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@ns", txtNgaySinh.Text.ToString());
                    cmd.Parameters.AddWithValue("@khoi", ddlKhoi.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@lop", ddlLop.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@sdtph", txtSDTPhuHuynh.Text.ToString());
                    cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.ToString());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    DS_Load();
                    loadtrang();
                    Label2.Text = "Thêm thông tin học sinh: "+mahs+" thành công!";
                    txtMaHocSinh.Enabled = true;
                }
                else Label2.Text = "Mã của học sinh: "+mahs+" đã tồn tại!";
            }
        }

        public int KiemTra()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtMaHocSinh.Text;
                string sql = "select * from HOCSINH where MAHS='" + mahs + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }

        protected void btnTim_Click1(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                if (ddlTCTK.SelectedValue.ToString() == "MAHOCSINH")
                {
                    string mahs = txtNhapLieu.Text;
                    string sql = "select * from HOCSINH where MAHS='" + mahs + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    if (dt.Rows.Count < 1)
                    {
                        Label3.Text = " NHẬP MÃ HỌC SINH KHÔNG ĐÚNG";
                        // Label3.Focus();
                        dgvDanhSachHocSinh.DataSource = dt;
                        dgvDanhSachHocSinh.DataBind();
                    }
                    else
                    {
                        dgvDanhSachHocSinh.DataSource = dt;
                        dgvDanhSachHocSinh.DataBind();
                        Label3.Text = "";
                    }

                }
                else if (ddlTCTK.SelectedValue.ToString() == "Lop")
                {
                    string lop = txtNhapLieu.Text;
                    string sql = "select * from HOCSINH where LOP='" + lop + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    if (dt.Rows.Count < 1)
                    {
                        Label3.Text = "NHẬP LỚP KHÔNG ĐÚNG";
                        Label2.Text = "";
                        // Label3.Focus();
                        dgvDanhSachHocSinh.DataSource = dt;
                        dgvDanhSachHocSinh.DataBind();
                    }
                    else
                    {
                        dgvDanhSachHocSinh.DataSource = dt;
                        dgvDanhSachHocSinh.DataBind();
                        Label3.Text = "";
                    }


                }
                else
                {
                    string khoi = txtNhapLieu.Text;
                    string sql = "select * from HOCSINH where KHOI='" + khoi + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    if (dt.Rows.Count < 1)
                    {
                        Label3.Text = "NHẬP KHỐI KHÔNG ĐÚNG";
                        Label2.Text = "";
                        // Label3.Focus();
                        dgvDanhSachHocSinh.DataSource = dt;
                        dgvDanhSachHocSinh.DataBind();

                    }
                    else
                    {
                        dgvDanhSachHocSinh.DataSource = dt;
                        dgvDanhSachHocSinh.DataBind();
                        Label3.Text = "";

                    }

                }
            }
            KiemTraTimKiem();

        }
        public bool KiemTraTimKiem()
        {
            string kt = txtNhapLieu.Text;
            //int result;
            if (txtNhapLieu.Text.ToString().Length == 0)
            {
                Label2.Text = "THÔNG TIN TÌM KIẾM KHÔNG ĐƯỢC BỎ TRỐNG";
                Label3.Text = "";
                Label2.Focus();
                return
                    false;
            }
            else
            {
                Label2.Text = "";
            }
            return true;
        } 

       
        
    }
}