﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace QLKQHT
{
    public partial class HS : System.Web.UI.Page
    {
        string connect = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            DS_Load();
        }
        private void DS_Load()
        {
            string taikhoan = Session["tk"].ToString();
            Response.Write("Chào bạn: " + taikhoan);
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "select HOCSINH.MAHS, TENHOCSINH, GIOITINH, LOP, NGAYSINH,DIEMHK1,DIEMHK2,DIEMTB,HANHKIEM,XEPLOAI from HOCSINH, DIEM  where HOCSINH.MAHS = DIEM.MAHS and HOCSINH.MAHS='" + taikhoan + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    grvHocSinh.DataSource = dt;
                    grvHocSinh.DataBind();
                
            }
        }

        protected void btnDangXuat_Click(object sender, EventArgs e)
        {
            Response.Redirect("dangnhap.aspx");
        }

    }
}