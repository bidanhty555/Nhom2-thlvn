﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace QLKQHT
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string connect = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;
        string mahs, tenhs,khoi,lop ,sdtph, diachi;
        Boolean gt;
        DateTime ns;
        protected void Page_Load(object sender, EventArgs e)
        {
            DDL_Load();
            DS_Load();
        }
        private void DDL_Load() 
        {
            if (ddlKhoi.SelectedItem.ToString() == "6")
            {
                ddlLop.Items.Clear();
                ddlLop.Items.Add("6A");
                ddlLop.Items.Add("6B");
                ddlLop.Items.Add("6C");
                ddlLop.Items.Add("6D");
            }
            else if (ddlKhoi.SelectedItem.ToString() == "7")
            {
                ddlLop.Items.Clear();
                ddlLop.Items.Add("7A");
                ddlLop.Items.Add("7B");
                ddlLop.Items.Add("7C");
                ddlLop.Items.Add("7D");
            }
            else if (ddlKhoi.SelectedItem.ToString() == "8")
            {
                ddlLop.Items.Clear();
                ddlLop.Items.Add("8A");
                ddlLop.Items.Add("8B");
                ddlLop.Items.Add("8C");
                ddlLop.Items.Add("8D");
            }
            else if (ddlKhoi.SelectedItem.ToString() == "9")
            {
                ddlLop.Items.Clear();
                ddlLop.Items.Add("9A");
                ddlLop.Items.Add("9B");
                ddlLop.Items.Add("9C");
                ddlLop.Items.Add("9D");
            }
        }

        private void DS_Load()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "select * from HOCSINH";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                dgvDanhSachHocSinh.DataSource = dt;
                dgvDanhSachHocSinh.DataSourceID = null;
                dgvDanhSachHocSinh.DataBind();
            }
        }
        protected void dgvDanhSachHocSinh_SelectedIndexChanged(object sender, EventArgs e)
        {
          string maHS = dgvDanhSachHocSinh.SelectedRow.Cells[1].Text;
            using (SqlConnection conn = new SqlConnection(connect))
            {
                
                string sql = "select * from HOCSINH where MAHS=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma",maHS );
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    mahs = (string)dr["MAHS"];
                    tenhs = (string)dr["TENHOCSINH"];
                    gt = (Boolean)dr["GIOITINH"];
                    ns = (DateTime)dr["NGAYSINH"];
                    khoi = (string)dr["KHOI"];
                    lop = (string)dr["LOP"];
                    sdtph = (string)dr["SDTPHUHUYNH"];
                    diachi = (string)dr["DIACHI"];
                    txtMaHocSinh.Text = mahs;
                    txtTen.Text = tenhs;
                    if (gt == true)
                    {
                        RadioButtonList1.SelectedIndex = 0;
                    }
                    else
                    {
                        RadioButtonList1.SelectedIndex = 1;
                    }
                    txtNgaySinh.Text = ns.ToString();
                    txtSDTPhuHuynh.Text = sdtph;
                    txtDiaChi.Text = diachi;
                    ddlKhoi.SelectedItem.Text = khoi; 
                    ddlLop.SelectedItem.Text = lop;
                    DDL_Load();
                    
                    
                }
                txtMaHocSinh.Enabled = false;
            }
            
        }
        private void loadtrang()
        {
            txtMaHocSinh.Text = "";
            txtTen.Text = "";
            RadioButtonList1.SelectedIndex = -1;
            txtNgaySinh.Text = "";
            txtSDTPhuHuynh.Text = "";
            txtDiaChi.Text = "";
        }
        protected void btnSua_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {

                string sql = "update HOCSINH set TENHOCSINH=@ten,GIOITINH=@gt,NGAYSINH=@ns,KHOI=@khoi,LOP=@lop,SDTPHUHUYNH=@sdtph,DIACHI=@diachi where MAHS=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", txtMaHocSinh.Text.ToString());
                cmd.Parameters.AddWithValue("@ten", txtTen.Text.ToString());
                cmd.Parameters.AddWithValue("@gt", RadioButtonList1.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@ns", txtNgaySinh.Text.ToString());
                cmd.Parameters.AddWithValue("@khoi",ddlKhoi.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@lop", ddlLop.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@sdtph", txtSDTPhuHuynh.Text.ToString());
                cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.ToString());
                conn.Open();
                cmd.ExecuteNonQuery();
                DS_Load();
                loadtrang();
                Label2.Text = "Sửa thông tin học sinh: " + mahs + " thành công!";
                txtMaHocSinh.Enabled = true;
            }
        }

        protected void btnXoa_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "delete HOCSINH where MAHS=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", txtMaHocSinh.Text.ToString());
                conn.Open();
                cmd.ExecuteNonQuery();
                DS_Load();
                loadtrang();
                txtMaHocSinh.Enabled = true;
            }
        }

        protected void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtMaHocSinh.Text;
                if (KiemTra() != 1)
                {   
                    
                    string sql = "INSERT INTO HOCSINH (MAHS,TENHOCSINH,GIOITINH,NGAYSINH,KHOI,LOP,SDTPHUHUYNH,DIACHI) VALUES (@ma,@ten,@gt,@ns,@khoi,@lop,@sdtph,@diachi)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMaHocSinh.Text.ToString());
                    cmd.Parameters.AddWithValue("@ten", txtTen.Text.ToString());
                    cmd.Parameters.AddWithValue("@gt", RadioButtonList1.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@ns", txtNgaySinh.Text.ToString());
                    cmd.Parameters.AddWithValue("@khoi", ddlKhoi.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@lop", ddlLop.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@sdtph", txtSDTPhuHuynh.Text.ToString());
                    cmd.Parameters.AddWithValue("@diachi", txtDiaChi.Text.ToString());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    DS_Load();
                    loadtrang();
                    Label2.Text = "Thêm thông tin học sinh: "+mahs+" thành công!";
                    txtMaHocSinh.Enabled = true;
                }
                else Label2.Text = "Mã của học sinh: "+mahs+" tại!";
            }
        }

        public int KiemTra()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtMaHocSinh.Text;
                string sql = "select * from HOCSINH where MAHS='" + mahs + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }

        protected void btnTim_Click1(object sender, EventArgs e)
        {
             using (SqlConnection conn = new SqlConnection(connect))
             {
                 if (ddlTCTK.SelectedValue.ToString() == "MAHOCSINH")
                 {
                     string mahs = txtNhapLieu.Text;
                     string sql = "select * from HOCSINH where MAHS='" + mahs + "'";
                     SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                     DataTable dt = new DataTable();
                     conn.Open();
                     da.Fill(dt);
                     if (dt.Rows.Count < 1)
                     {
                         Label3.Text = "THÔNG TIN TÌM KIẾM KHÔNG PHÙ HỢP";
                         // Label3.Focus();
                         dgvDanhSachHocSinh.DataSource = dt;
                         dgvDanhSachHocSinh.DataBind();
                     }
                     else
                     {
                         dgvDanhSachHocSinh.DataSource = dt;
                         dgvDanhSachHocSinh.DataBind();
                         Label3.Text = "";
                     }
                            
                 }
                 else if  (ddlTCTK.SelectedValue.ToString() == "Lop")
                 {
                     string lop = txtNhapLieu.Text;
                     string sql = "select * from HOCSINH where LOP='" + lop + "'";
                     SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                     DataTable dt = new DataTable();
                     conn.Open();
                     da.Fill(dt);
                     if (dt.Rows.Count < 1)
                     {
                         Label3.Text = "THÔNG TIN TÌM KIẾM KHÔNG PHÙ HỢP";
                        // Label3.Focus();
                         dgvDanhSachHocSinh.DataSource = dt;
                         dgvDanhSachHocSinh.DataBind();
                     }
                     else {
                         dgvDanhSachHocSinh.DataSource = dt;
                         dgvDanhSachHocSinh.DataBind();
                         Label3.Text = "";
                     }
                    

                 }
                 else
                 {
                     string khoi = txtNhapLieu.Text;
                     string sql = "select * from HOCSINH where KHOI='" + khoi + "'";
                     SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                     DataTable dt = new DataTable();
                     conn.Open();
                     da.Fill(dt);
                     if (dt.Rows.Count < 1)
                     {
                         Label3.Text = "THÔNG TIN TÌM KIẾM  KHÔNG PHÙ HỢP";
                         // Label3.Focus();
                         dgvDanhSachHocSinh.DataSource = dt;
                         dgvDanhSachHocSinh.DataBind();
                     }
                     else
                     {
                         dgvDanhSachHocSinh.DataSource = dt;
                         dgvDanhSachHocSinh.DataBind();
                         Label3.Text = "";
                     }

                 }
              }
             KiemTraTimKiem();
                
        }
        public bool KiemTraTimKiem()
        {
            string kt = txtNhapLieu.Text;
            //int result;
            if (txtNhapLieu.Text.ToString().Length == 0)
            {
                Label2.Text = "THÔNG TIN TÌM KIẾM KHÔNG ĐƯỢC BỎ TRỐNG";
                Label2.Focus();
                return
                    false;
            }
            else
            {
                Label2.Text = "";
            }
            return true;            
        }        
    }
}