﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace QLKQHT
{
    public partial class QLD : System.Web.UI.Page
    {
        string connect = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;
        float diemhk1, diemhk2, diemtb;
        string mahs, hanhkiem, xl;
        protected void Page_Load(object sender, EventArgs e)
        {
            DS_Load();
            if (!IsPostBack)
                load();
            Label2.Text = null;
            txtDiemTB.Enabled = false;
            txtXepLoai.Enabled = false;
        }
        private void DS_Load()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "select * from DIEM where MAHS=mahs";
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                DataTable dt = new DataTable();
                conn.Open();
                da.Fill(dt);
                dgvDiem.DataSource = dt;
                dgvDiem.DataBind();
            }
        }
        private void load()
        {
            Label2.Text = null;
            float tb = 0;
            tb = (float.Parse(txtDiemHK1.Text.ToString()) + ((float.Parse(txtDiemHK2.Text.ToString())) * 2)) / 3;
            if (tb <= 0.9) txtDiemTB.Text = tb.ToString("0.#");
            else txtDiemTB.Text = tb.ToString("#.0");
            if (((float.Parse(txtDiemTB.Text) <= 10) && (float.Parse(txtDiemTB.Text) >= 8)) && ((ddlHanhKiem.SelectedValue.ToString() == "Tốt") || (ddlHanhKiem.SelectedValue.ToString() == "Khá")))
                txtXepLoai.Text = "Giỏi";
            if ((((float.Parse(txtDiemTB.Text) < 8) && (float.Parse(txtDiemTB.Text) >= 6.5)) && ((ddlHanhKiem.SelectedValue.ToString() == "Tốt") || (ddlHanhKiem.SelectedValue.ToString() == "Khá")))
                || (((float.Parse(txtDiemTB.Text) <= 10) && (float.Parse(txtDiemTB.Text) >= 8)) && (ddlHanhKiem.SelectedValue.ToString() == "TB")))
                txtXepLoai.Text = "Khá";
            if (((float.Parse(txtDiemTB.Text) < 6.5) && (float.Parse(txtDiemTB.Text) >= 5))
                || (((float.Parse(txtDiemTB.Text) < 8) && (float.Parse(txtDiemTB.Text) >= 6.5)) && (ddlHanhKiem.SelectedValue.ToString() == "TB"))
                || (((float.Parse(txtDiemTB.Text) <= 10) && (float.Parse(txtDiemTB.Text) >= 8)) && (ddlHanhKiem.SelectedValue.ToString() == "Yếu")))
                txtXepLoai.Text = "TB";
            if (((float.Parse(txtDiemTB.Text) < 5) && ((ddlHanhKiem.SelectedValue.ToString() == "TB") || (ddlHanhKiem.SelectedValue.ToString() == "Yếu") || (ddlHanhKiem.SelectedValue.ToString() == "Khá")))
                || (((float.Parse(txtDiemTB.Text) < 8) && (float.Parse(txtDiemTB.Text) >= 6.5)) && (ddlHanhKiem.SelectedValue.ToString() == "Yếu"))
                || (((float.Parse(txtDiemTB.Text) < 6.5) && (float.Parse(txtDiemTB.Text) >= 5)) && (ddlHanhKiem.SelectedValue.ToString() == "Yếu")))
                txtXepLoai.Text = "Yếu";
            if ((float.Parse(txtDiemTB.Text) < 5) && (ddlHanhKiem.SelectedValue.ToString() == "Tốt")) Label2.Text = "Học sinh có học lực yếu không thể đạt hạnh kiểm tốt!";

            
        }
        public int kiemtramahs()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string kt = txtMAHS.Text;
                string sql = "select * from HOCSINH where MAHS='" + kt + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
        

        
        protected void btnThem_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtMAHS.Text;
                if (txtMAHS.Text=="")
                    Label2.Text="Vui lòng nhập đầy đủ thông tin!";
                else if(KiemTra() != 1)
                {
                    string sql = "insert into DIEM (MAHS,DIEMHK1,DIEMHK2,DIEMTB,HANHKIEM,XEPLOAI) values(@mahs,@diemhk1,@diemhk2,@diemtb,@hanhkiem,@xeploai)";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@mahs", txtMAHS.Text.ToString());
                    cmd.Parameters.AddWithValue("@diemhk1", txtDiemHK1.Text.ToString());
                    cmd.Parameters.AddWithValue("@diemhk2", txtDiemHK2.Text.ToString());
                    cmd.Parameters.AddWithValue("@diemtb", txtDiemTB.Text.ToString());
                    cmd.Parameters.AddWithValue("@xeploai", txtXepLoai.Text.ToString());
                    cmd.Parameters.AddWithValue("@hanhkiem", ddlHanhKiem.SelectedValue.ToString());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    Label2.Text = "Thêm" + mahs + "thành công";
                    DS_Load();
                }
                else Label2.Text = "Mã học sinh: " + mahs + " đã tồn tại";
               

            }
        }

        public int KiemTra()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string kt = txtMAHS.Text;
                string sql = "select * from DIEM where MAHS='" + kt + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }

        protected void txtDiemHK1_TextChanged(object sender, EventArgs e)
        {
            load();
        }

        protected void txtDiemHK2_TextChanged(object sender, EventArgs e)
        {
            load();
        }

        protected void ddlHanhKiem_SelectedIndexChanged(object sender, EventArgs e)
        {
            load();
        }

        protected void btnTim_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                if (ddlTCTK.SelectedValue.ToString() == "MAHOCSINH")
                {
                    string mahs = txtNhapLieu.Text;
                    string sql = "select * from DIEM where MAHS='" + mahs + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    if (dt.Rows.Count < 1)
                    {
                        Label3.Text = " NHẬP MÃ HỌC SINH KHÔNG ĐÚNG";
                    }
                    else
                    {
                        dgvDiem.DataSource = dt;
                        dgvDiem.DataBind();
                        Label3.Text = "";
                    }
                    KiemTraTimKiem();

                }
                else if (ddlTCTK.SelectedValue.ToString() == "G")
                {
                    string xl = "Gioi";
                    string sql = "select * from DIEM where XEPLOAI='" + xl + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    dgvDiem.DataSource = dt;
                    dgvDiem.DataBind();
                }
                else if (ddlTCTK.SelectedValue.ToString() == "K")
                {
                    string xl = "Khá";
                    string sql = "select * from DIEM where XEPLOAI='" + xl + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    dgvDiem.DataSource = dt;
                    dgvDiem.DataBind();

                }
                else if (ddlTCTK.SelectedValue.ToString() == "TB")
                {
                    string xl = "TB";
                    string sql = "select * from DIEM where XEPLOAI='" + xl + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    dgvDiem.DataSource = dt;
                    dgvDiem.DataBind();

                }
                else if (ddlTCTK.SelectedValue.ToString() == "Y")
                {
                    string xl = "Yếu";
                    string sql = "select * from DIEM where XEPLOAI='" + xl + "'";
                    SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                    DataTable dt = new DataTable();
                    conn.Open();
                    da.Fill(dt);
                    dgvDiem.DataSource = dt;
                    dgvDiem.DataBind();

                }

            }
        }
        public bool KiemTraTimKiem()
        {
            string kt = txtNhapLieu.Text;
            //int result;
            if (txtNhapLieu.Text.ToString().Length == 0)
            {
                Label2.Text = "THÔNG TIN TÌM KIẾM KHÔNG ĐƯỢC BỎ TRỐNG";
                Label3.Text = "";
                Label2.Focus();
                return
                    false;
            }
            else
            {
                Label2.Text = "";
            }
            return true;
        }

        protected void dgvDiem_SelectedIndexChanged(object sender, EventArgs e)
        {
            string maHS = dgvDiem.SelectedRow.Cells[1].Text;
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string sql = "select * from DIEM where MAHS=@ma";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@ma", maHS);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    mahs = (string)dr["MAHS"];
                    diemhk1 = (float)(double)dr["DIEMHK1"];
                    diemhk2 = (float)(double)dr["DIEMHK2"];
                    diemtb = (float)(double)dr["DIEMTB"];
                    hanhkiem = (string)dr["HANHKIEM"];
                    xl = (string)dr["XEPLOAI"];
                }
                txtMAHS.Text = mahs;
                txtMAHS.Enabled = false;
                txtDiemHK1.Text = diemhk1.ToString();
                txtDiemHK2.Text = diemhk2.ToString();
                txtDiemTB.Text = diemtb.ToString();
                ddlHanhKiem.Text = hanhkiem;
                txtXepLoai.Text = xl;
            }
        }

        protected void btnSua_Click1(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtMAHS.Text;
                if (txtMAHS.Text == "")
                    Label2.Text = "Vui lòng nhập đầy đủ thông tin!";
                else
                {
                    string sql = "update DIEM set DIEMHK1=@diemhk1,DIEMHK2=@diemhk2,DIEMTB=@diemtb,HANHKIEM=@hanhkiem,XEPLOAI=@xl where MAHS=@ma";
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("@ma", txtMAHS.Text.ToString());
                    cmd.Parameters.AddWithValue("@diemhk1", float.Parse(txtDiemHK1.Text.ToString()));
                    cmd.Parameters.AddWithValue("@diemhk2", float.Parse(txtDiemHK2.Text.ToString()));
                    cmd.Parameters.AddWithValue("@diemtb", float.Parse(txtDiemTB.Text.ToString()));
                    cmd.Parameters.AddWithValue("@hanhkiem", ddlHanhKiem.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@xl", txtXepLoai.Text.ToString());
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    Label2.Text = "Sửa điểm học sinh: " + mahs + " thành công!";
                    DS_Load();
                    txtMAHS.Enabled = true;
                }

            }
        }

    }
}