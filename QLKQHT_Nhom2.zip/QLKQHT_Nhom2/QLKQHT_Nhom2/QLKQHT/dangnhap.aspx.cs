﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace QLKQHT
{
    public partial class dangnhap : System.Web.UI.Page
    {

        string connect = ConfigurationManager.ConnectionStrings["MyDB"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDangNhap_Click(object sender, EventArgs e)
        {
            string taikhoan = txtTenDangNhap.Text;
            string matkhau = txtMatKhau.Text;

            if ((taikhoan == "") && (matkhau == ""))
                lblThongBao.Text = "Vui lòng nhập đầy đủ thông tin!";
            else if ((KiemTra() == 1) && (taikhoan == matkhau))
            {
                Session["tk"] = taikhoan;
                Response.Redirect("HS.aspx");
            }
            else if ((KiemTragv() == 1) && (taikhoan == matkhau))
                Response.Redirect("QLHS.aspx");
            else if (KiemTraqt() == 1)
                Response.Redirect("QLGV.aspx");
            else lblThongBao.Text = "Sai tên đăng nhập hoặc mật khẩu!";
        }
        public int KiemTra()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string mahs = txtTenDangNhap.Text;
                string sql = "select * from HOCSINH where MAHS='" + mahs + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
        public int KiemTragv()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string magv = txtTenDangNhap.Text;
                string sql = "select * from GIAOVIEN where MAGIAOVIEN='" + magv + "'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
                
            }
        }
        public int KiemTraqt()
        {
            using (SqlConnection conn = new SqlConnection(connect))
            {
                string ten = txtTenDangNhap.Text;
                string mk = txtMatKhau.Text;
                string sql = "select * from ADMIN where TAIKHOAN='" + ten + "'and MATKHAU='"+mk+"'";
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
}